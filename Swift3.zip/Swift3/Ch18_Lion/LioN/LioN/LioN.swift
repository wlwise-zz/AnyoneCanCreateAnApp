//
//  LioN.swift
//  LioN
//
//  Created by Wendy Wise on 9/24/16.
//  Copyright © 2016 WisaAbility. All rights reserved.
//

import Foundation

class Lion {
    var lionName = ""
    var lionDescription = ""
    var like = 1
}
