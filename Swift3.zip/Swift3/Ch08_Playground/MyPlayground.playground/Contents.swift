//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

str

str = "this is a string"

str

var myString : String = "hello"

var myCatsAge = 15

var inFiveYears = myCatsAge + 5

var tenYearsAgo = myCatsAge - 10

var cost = 12.47

var tax = 1.07

cost * tax


